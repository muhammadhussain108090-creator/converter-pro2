# ConvertPro

A deployable React + Vite file toolkit for Netlify. Version 1 performs PDF and image operations locally in the browser. Firebase Google sign-in and optional Firestore activity logging are supported when configured.

## Working tools in this version

- Merge multiple PDF files
- Extract a page or page range from a PDF
- Rotate all pages in a PDF
- Convert multiple images into one PDF
- Compress/convert images to WebP, JPG or PNG
- Resize images with optional aspect-ratio preservation

The app does not pretend to support Word/PDF conversion that it cannot perform. DOCX-to-PDF and PDF-to-editable-Word require a document-conversion engine (for example LibreOffice on a separate server); these are not included in this free serverless starter.

## Run locally

1. Install Node.js 20 or newer.
2. Extract the project.
3. In the project folder run:

   ```bash
   npm install
   npm run dev
   ```

4. Open the local URL shown by Vite.

To test a production build:

```bash
npm run build
npm run preview
```

## Deploy to Netlify

### GitHub method

1. Create a GitHub repository and upload the project files.
2. In Netlify choose **Add new site → Import an existing project**.
3. Select the repository.
4. Build command: `npm run build`
5. Publish directory: `dist`
6. Deploy.

The included `netlify.toml` configures the build, functions folder and SPA fallback.

### Netlify CLI method

```bash
npm install
npm run build
npx netlify deploy --prod --dir=dist
```

## Optional Firebase setup

Firebase is optional. All file tools work without accounts.

1. Create a project at https://console.firebase.google.com/
2. Add a Web App and copy its configuration.
3. Enable **Authentication → Sign-in method → Google**.
4. Create a **Cloud Firestore** database.
5. Add these environment variables in Netlify → Site configuration → Environment variables:

   - `VITE_FIREBASE_API_KEY`
   - `VITE_FIREBASE_AUTH_DOMAIN`
   - `VITE_FIREBASE_PROJECT_ID`
   - `VITE_FIREBASE_STORAGE_BUCKET`
   - `VITE_FIREBASE_MESSAGING_SENDER_ID`
   - `VITE_FIREBASE_APP_ID`

6. Redeploy after adding variables.

For local development, copy `.env.example` to `.env.local` and fill in the same values.

### Firestore security rules

The app writes optional activity entries to `users/{uid}/activity`. Use rules that only let an authenticated user read/write their own activity:

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/activity/{activityId} {
      allow read, create: if request.auth != null
                          && request.auth.uid == userId;
      allow update, delete: if false;
    }
  }
}
```

Do not make your Firestore database publicly readable or writable.

## Backend health check

After deployment, visit:

`https://YOUR-SITE.netlify.app/.netlify/functions/health`

It should return JSON confirming the Netlify function is online.

## Privacy and file limits

- PDF and image processing is performed in the browser with `pdf-lib` and the browser Canvas API.
- Files are not sent to ConvertPro's backend by these tools.
- The app limits each selected file to 50 MB and the selection to 20 files. Actual practical limits depend on the user's device memory and browser.
- Do not claim files are automatically deleted from a server: the current tools do not upload them in the first place.
- Avoid processing confidential documents on shared devices.

## Important production notes

- Add your own domain and replace the sample contact address in `src/App.jsx`.
- Add a privacy policy and terms before public launch.
- Add monitoring, accessibility testing and cross-browser testing.
- Firebase web configuration is public client configuration, not a server secret. Protect data with Firebase Security Rules.
- Netlify's free plan has usage limits; check current plan limits before launching at scale.
