import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  FileText, Image as ImageIcon, Scissors, Layers, RotateCw, FileImage,
  Download, Upload, Search, ShieldCheck, Zap, Menu, X, CheckCircle2,
  AlertCircle, ArrowRight, Sparkles, Trash2, Github, LockKeyhole, User,
  LogOut, ChevronDown, FilePlus2, RefreshCw, Maximize2, Minimize2
} from "lucide-react";
import { PDFDocument, degrees } from "pdf-lib";
import { auth, db, googleProvider, firebaseReady } from "./firebase";
import { onAuthStateChanged, signInWithPopup, signOut } from "firebase/auth";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";

const tools = [
  { id:"merge", name:"Merge PDF", desc:"Combine multiple PDFs into one file.", category:"PDF", icon:Layers, tag:"Popular" },
  { id:"split", name:"Split PDF", desc:"Extract a page range into a new PDF.", category:"PDF", icon:Scissors },
  { id:"rotate", name:"Rotate PDF", desc:"Rotate all pages in your PDF.", category:"PDF", icon:RotateCw },
  { id:"images-pdf", name:"Images to PDF", desc:"Turn JPG and PNG images into a PDF.", category:"PDF", icon:FileImage },
  { id:"compress-image", name:"Compress Image", desc:"Reduce image file size in your browser.", category:"Image", icon:Minimize2, tag:"Popular" },
  { id:"resize-image", name:"Resize Image", desc:"Change image dimensions while keeping quality.", category:"Image", icon:Maximize2 },
  { id:"convert-image", name:"Convert Image", desc:"Convert PNG, JPG and WebP formats.", category:"Image", icon:RefreshCw },
];

const fmtBytes = (n=0) => n < 1024 ? `${n} B` : n < 1048576 ? `${(n/1024).toFixed(1)} KB` : `${(n/1048576).toFixed(2)} MB`;
const saveBlob = (blob, name) => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
};
const safeName = (name, ext) => `${name.replace(/\.[^.]+$/, "").replace(/[^\w-]+/g, "-") || "convertpro"}-${Date.now()}.${ext}`;

function App() {
  const [active, setActive] = useState("home");
  const [toolId, setToolId] = useState("merge");
  const [files, setFiles] = useState([]);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState(null);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [splitRange, setSplitRange] = useState("1");
  const [rotation, setRotation] = useState("90");
  const [imageFormat, setImageFormat] = useState("image/webp");
  const [quality, setQuality] = useState(0.82);
  const [width, setWidth] = useState("");
  const [height, setHeight] = useState("");
  const [keepRatio, setKeepRatio] = useState(true);
  const [user, setUser] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const inputRef = useRef(null);

  useEffect(() => {
    if (!auth) return;
    return onAuthStateChanged(auth, setUser);
  }, []);

  const selectedTool = tools.find(t => t.id === toolId) || tools[0];
  const filtered = useMemo(() => tools.filter(t =>
    (category === "All" || t.category === category) &&
    `${t.name} ${t.desc}`.toLowerCase().includes(query.toLowerCase())
  ), [category, query]);

  const showNotice = (type, message) => {
    setNotice({type, message});
    window.setTimeout(() => setNotice(null), 5000);
  };

  const chooseTool = (id) => {
    setToolId(id); setFiles([]); setActive("tool"); setNotice(null);
    window.scrollTo({top:0, behavior:"smooth"});
  };

  const addFiles = (list) => {
    const incoming = Array.from(list || []);
    if (!incoming.length) return;
    const isPdfTool = ["merge","split","rotate"].includes(toolId);
    const accepted = incoming.filter(f => isPdfTool ? f.type === "application/pdf" || f.name.toLowerCase().endsWith(".pdf") : f.type.startsWith("image/"));
    if (accepted.length !== incoming.length) showNotice("error", isPdfTool ? "Please select PDF files only." : "Please select image files only.");
    if (accepted.some(f => f.size > 50 * 1024 * 1024)) {
      showNotice("error", "Each file must be smaller than 50 MB.");
      return;
    }
    setFiles(prev => [...prev, ...accepted].slice(0, 20));
  };

  const recordUsage = async (toolName) => {
    if (user && db) {
      try { await addDoc(collection(db, "users", user.uid, "activity"), { tool: toolName, createdAt: serverTimestamp() }); }
      catch (e) { console.warn("Activity history could not be saved:", e); }
    }
  };

  const runTool = async () => {
    if (!files.length) return showNotice("error", "Choose at least one file first.");
    setBusy(true); setNotice(null);
    try {
      if (toolId === "merge") {
        if (files.length < 2) throw new Error("Add at least two PDF files to merge.");
        const merged = await PDFDocument.create();
        for (const file of files) {
          const src = await PDFDocument.load(await file.arrayBuffer());
          const pages = await merged.copyPages(src, src.getPageIndices());
          pages.forEach(p => merged.addPage(p));
        }
        const bytes = await merged.save();
        saveBlob(new Blob([bytes], {type:"application/pdf"}), "convertpro-merged.pdf");
      } else if (toolId === "split") {
        if (files.length !== 1) throw new Error("Choose exactly one PDF to split.");
        const src = await PDFDocument.load(await files[0].arrayBuffer());
        const total = src.getPageCount();
        const match = splitRange.trim().match(/^(\d+)(?:\s*-\s*(\d+))?$/);
        if (!match) throw new Error("Enter a page or range, for example 2 or 2-5.");
        const start = Number(match[1]), end = Number(match[2] || match[1]);
        if (start < 1 || end < start || end > total) throw new Error(`This PDF has ${total} pages. Enter a valid range.`);
        const out = await PDFDocument.create();
        const pages = await out.copyPages(src, Array.from({length:end-start+1}, (_,i)=>start-1+i));
        pages.forEach(p=>out.addPage(p));
        saveBlob(new Blob([await out.save()], {type:"application/pdf"}), "convertpro-split.pdf");
      } else if (toolId === "rotate") {
        if (files.length !== 1) throw new Error("Choose exactly one PDF to rotate.");
        const pdf = await PDFDocument.load(await files[0].arrayBuffer());
        const turn = Number(rotation);
        pdf.getPages().forEach(p => p.setRotation(degrees((p.getRotation().angle + turn) % 360)));
        saveBlob(new Blob([await pdf.save()], {type:"application/pdf"}), safeName(files[0].name,"pdf"));
      } else if (toolId === "images-pdf") {
        const pdf = await PDFDocument.create();
        for (const file of files) {
          const bytes = await file.arrayBuffer();
          let image;
          if (file.type === "image/png" || file.name.toLowerCase().endsWith(".png")) image = await pdf.embedPng(bytes);
          else if (["image/jpeg","image/jpg"].includes(file.type) || /\.(jpe?g)$/i.test(file.name)) image = await pdf.embedJpg(bytes);
          else {
            const converted = await imageFileToBlob(file, "image/jpeg", 0.92);
            image = await pdf.embedJpg(await converted.arrayBuffer());
          }
          const page = pdf.addPage([image.width, image.height]);
          page.drawImage(image, {x:0,y:0,width:image.width,height:image.height});
        }
        saveBlob(new Blob([await pdf.save()], {type:"application/pdf"}), "convertpro-images.pdf");
      } else {
        if (files.length !== 1) throw new Error("Choose exactly one image for this tool.");
        const file = files[0];
        const img = await loadImage(file);
        let w = img.naturalWidth, h = img.naturalHeight;
        if (toolId === "resize-image") {
          const targetW = Number(width), targetH = Number(height);
          if (!targetW && !targetH) throw new Error("Enter a width or height.");
          if (keepRatio) {
            if (targetW) { w = targetW; h = Math.round(img.naturalHeight * targetW / img.naturalWidth); }
            else { h = targetH; w = Math.round(img.naturalWidth * targetH / img.naturalHeight); }
          } else { w = targetW || w; h = targetH || h; }
          if (w < 1 || h < 1 || w > 10000 || h > 10000) throw new Error("Dimensions must be between 1 and 10,000 pixels.");
        }
        const canvas = document.createElement("canvas"); canvas.width = w; canvas.height = h;
        const ctx = canvas.getContext("2d");
        if (imageFormat === "image/jpeg") { ctx.fillStyle = "#ffffff"; ctx.fillRect(0,0,w,h); }
        ctx.drawImage(img,0,0,w,h);
        const mime = toolId === "convert-image" ? imageFormat : (file.type === "image/jpeg" ? "image/jpeg" : "image/webp");
        const blob = await new Promise(resolve => canvas.toBlob(resolve, mime, quality));
        if (!blob) throw new Error("Your browser could not process this image format.");
        const ext = mime === "image/jpeg" ? "jpg" : mime === "image/png" ? "png" : "webp";
        saveBlob(blob, safeName(file.name, ext));
      }
      await recordUsage(selectedTool.name);
      showNotice("success", "Your file is ready. The download should start automatically.");
    } catch (err) {
      showNotice("error", err?.message || "Something went wrong while processing your file.");
    } finally { setBusy(false); }
  };

  const loadImage = (file) => new Promise((resolve,reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("Could not read this image.")); };
    img.src = url;
  });

  const imageFileToBlob = async (file, type, q) => {
    const img = await loadImage(file);
    const canvas = document.createElement("canvas");
    canvas.width = img.naturalWidth; canvas.height = img.naturalHeight;
    canvas.getContext("2d").drawImage(img,0,0);
    return new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error("Image conversion failed.")),type,q));
  };

  const login = async () => {
    if (!firebaseReady) return showNotice("error", "Firebase is not configured yet. Add your Firebase keys to the Netlify environment variables.");
    try { await signInWithPopup(auth, googleProvider); showNotice("success","Signed in successfully."); }
    catch(e) { showNotice("error", e.message || "Sign-in failed."); }
  };

  const goHome = () => { setActive("home"); setFiles([]); window.scrollTo({top:0,behavior:"smooth"}); };
  const isPdf = ["merge","split","rotate"].includes(toolId);
  const multiple = ["merge","images-pdf"].includes(toolId);

  return <div className="app-shell">
    <header className="topbar">
      <div className="nav-wrap">
        <button className="brand" onClick={goHome} aria-label="ConvertPro home">
          <span className="brand-mark"><FileText size={21}/></span>
          <span>Convert<span className="brand-accent">Pro</span></span>
        </button>
        <nav className={menuOpen ? "nav-links open" : "nav-links"}>
          <button onClick={goHome} className={active==="home"?"nav-active":""}>Home</button>
          <button onClick={()=>{setActive("home");document.getElementById("tools")?.scrollIntoView({behavior:"smooth"});setMenuOpen(false);}}>All tools</button>
          <a href="#how-it-works" onClick={()=>setMenuOpen(false)}>How it works</a>
        </nav>
        <div className="nav-actions">
          {user ? <div className="user-menu"><span className="avatar">{user.displayName?.[0] || <User size={15}/>}</span><span className="user-name">{user.displayName?.split(" ")[0]}</span><button className="icon-button" title="Sign out" onClick={()=>signOut(auth)}><LogOut size={16}/></button></div> :
            <button className="signin-button" onClick={login}><User size={16}/> Sign in</button>}
          <button className="mobile-menu icon-button" onClick={()=>setMenuOpen(v=>!v)} aria-label="Toggle menu">{menuOpen?<X/>:<Menu/>}</button>
        </div>
      </div>
    </header>

    <main>
      {active === "home" ? <>
        <section className="hero">
          <div className="hero-glow glow-one"></div><div className="hero-glow glow-two"></div>
          <div className="hero-content">
            <div className="eyebrow"><Sparkles size={14}/> SIMPLE. FAST. PRIVATE.</div>
            <h1>Every file.<br/><span>One workspace.</span></h1>
            <p className="hero-copy">Everything you need to convert, compress and manage your files — without complicated software.</p>
            <div className="hero-search">
              <Search size={19}/>
              <input value={query} onChange={e=>{setQuery(e.target.value);document.getElementById("tools")?.scrollIntoView({behavior:"smooth"});}} placeholder="Search for a tool..." aria-label="Search tools"/>
              <button onClick={()=>document.getElementById("tools")?.scrollIntoView({behavior:"smooth"})}>Explore tools <ArrowRight size={16}/></button>
            </div>
            <div className="hero-points"><span><ShieldCheck size={16}/> Files stay on your device</span><span><Zap size={16}/> No signup required</span><span><CheckCircle2 size={16}/> Free tools</span></div>
          </div>
          <div className="hero-art" aria-hidden="true">
            <div className="floating-file file-pdf"><div className="file-icon pdf-icon"><FileText/></div><div><b>document.pdf</b><small>PDF document</small></div><CheckCircle2 className="file-check"/></div>
            <div className="floating-file file-img"><div className="file-icon image-icon"><ImageIcon/></div><div><b>photo.webp</b><small>Optimized image</small></div><CheckCircle2 className="file-check"/></div>
            <div className="orbit orbit-a"></div><div className="orbit orbit-b"></div>
            <div className="center-convert"><RefreshCw size={48}/><span>CONVERT</span></div>
          </div>
        </section>

        <section className="trust-strip">
          <div><ShieldCheck/><span><b>Privacy first</b><small>Local browser processing</small></span></div>
          <div><Zap/><span><b>Quick workflow</b><small>Simple, focused tools</small></span></div>
          <div><LockKeyhole/><span><b>No account needed</b><small>Use tools instantly</small></span></div>
        </section>

        <section className="tools-section section-wrap" id="tools">
          <div className="section-heading">
            <div><div className="eyebrow dark-eyebrow">THE TOOLBOX</div><h2>What do you want to <span>do today?</span></h2><p>Pick a tool and get your file ready in a few clicks.</p></div>
            <span className="tool-count">{tools.length} tools available</span>
          </div>
          <div className="filter-row">
            <div className="category-tabs">{["All","PDF","Image"].map(c=><button key={c} className={category===c?"tab-active":""} onClick={()=>setCategory(c)}>{c}</button>)}</div>
            <label className="small-search"><Search size={16}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Find a tool"/></label>
          </div>
          <div className="tool-grid">
            {filtered.map(t=>{const Icon=t.icon;return <button className="tool-card" key={t.id} onClick={()=>chooseTool(t.id)}>
              <div className={`tool-icon ${t.category==="PDF"?"purple":"blue"}`}><Icon size={22}/></div>
              <div className="tool-card-title">{t.name}{t.tag&&<span className="popular-tag">{t.tag}</span>}</div>
              <p>{t.desc}</p><span className="card-arrow"><ArrowRight size={17}/></span>
            </button>;})}
            {!filtered.length&&<div className="empty-state">No tools found. Try another search.</div>}
          </div>
        </section>

        <section className="how-section" id="how-it-works">
          <div className="section-wrap">
            <div className="section-heading centered"><div><div className="eyebrow dark-eyebrow">THREE SIMPLE STEPS</div><h2>File work, made <span>easy.</span></h2><p>No complicated setup. Just choose, process and download.</p></div></div>
            <div className="steps-grid">
              <div className="step"><div className="step-number">01</div><div className="step-icon"><Upload/></div><h3>Choose your file</h3><p>Upload a PDF or image from your device.</p></div>
              <div className="step"><div className="step-number">02</div><div className="step-icon"><Sparkles/></div><h3>Process it</h3><p>Choose your settings and let ConvertPro do the work.</p></div>
              <div className="step"><div className="step-number">03</div><div className="step-icon"><Download/></div><h3>Download</h3><p>Save your converted file directly to your device.</p></div>
            </div>
          </div>
        </section>
      </> : <section className="workspace section-wrap">
        <button className="back-link" onClick={goHome}>← Back to all tools</button>
        <div className="workspace-heading"><div className={`tool-icon large ${selectedTool.category==="PDF"?"purple":"blue"}`}><selectedTool.icon size={27}/></div><div><div className="eyebrow dark-eyebrow">{selectedTool.category} TOOL</div><h1>{selectedTool.name}</h1><p>{selectedTool.desc}</p></div></div>
        <div className="workspace-card">
          <div className="upload-area" onClick={()=>inputRef.current?.click()} onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();addFiles(e.dataTransfer.files);}}>
            <input ref={inputRef} type="file" accept={isPdf?".pdf":"image/*"} multiple={multiple} onChange={e=>{addFiles(e.target.files);e.target.value="";}} hidden/>
            <div className="upload-icon"><Upload size={27}/></div>
            <h3>Drop your {isPdf?"PDF":"image"} {multiple?"files":"file"} here</h3>
            <p>or <span>browse files</span> from your device</p>
            <small>{isPdf?"PDF files":"JPG, PNG, WebP and other browser-supported images"} · Up to 50 MB per file</small>
          </div>
          {files.length>0&&<div className="file-list">
            <div className="file-list-head"><b>Selected files ({files.length})</b><button onClick={()=>setFiles([])} className="text-button">Clear all</button></div>
            {files.map((f,i)=><div className="file-row" key={`${f.name}-${i}`}><div className="file-row-icon">{isPdf?<FileText/>:<ImageIcon/>}</div><div className="file-info"><b>{f.name}</b><small>{fmtBytes(f.size)}</small></div><button className="remove-file" onClick={()=>setFiles(prev=>prev.filter((_,n)=>n!==i))} aria-label={`Remove ${f.name}`}><Trash2 size={16}/></button></div>)}
          </div>}
          {toolId==="split"&&<div className="setting-row"><label>Pages to extract <input value={splitRange} onChange={e=>setSplitRange(e.target.value)} placeholder="e.g. 1-3"/></label><small>Enter a single page or range, such as 2-5.</small></div>}
          {toolId==="rotate"&&<div className="setting-row"><label>Rotation angle <select value={rotation} onChange={e=>setRotation(e.target.value)}><option value="90">90° clockwise</option><option value="180">180°</option><option value="270">270° clockwise</option></select></label></div>}
          {["convert-image","compress-image"].includes(toolId)&&<div className="settings-grid"><label>Output format<select value={imageFormat} onChange={e=>setImageFormat(e.target.value)}><option value="image/webp">WebP (smaller)</option><option value="image/jpeg">JPG</option><option value="image/png">PNG</option></select></label><label>Quality <div className="range-wrap"><input type="range" min="0.3" max="1" step="0.05" value={quality} onChange={e=>setQuality(Number(e.target.value))}/><b>{Math.round(quality*100)}%</b></div></label></div>}
          {toolId==="resize-image"&&<div className="settings-grid"><label>Width (px)<input type="number" min="1" max="10000" value={width} onChange={e=>setWidth(e.target.value)} placeholder="e.g. 1200"/></label><label>Height (px)<input type="number" min="1" max="10000" value={height} onChange={e=>setHeight(e.target.value)} placeholder="e.g. 800"/></label><label className="check-setting"><input type="checkbox" checked={keepRatio} onChange={e=>setKeepRatio(e.target.checked)}/> Keep aspect ratio</label></div>}
          <div className="privacy-note"><ShieldCheck size={17}/><span><b>Your files are processed in your browser.</b> They are not uploaded to ConvertPro's servers.</span></div>
          <button className="process-button" disabled={busy||!files.length} onClick={runTool}>{busy?<><span className="spinner"/> Processing...</>:<>Process {files.length?`${files.length} file${files.length>1?"s":""}`:"file"} <ArrowRight size={18}/></>}</button>
        </div>
        <div className="workspace-foot"><LockKeyhole size={15}/> Files remain on your device during processing. Avoid uploading sensitive documents to websites you don't trust.</div>
      </section>}
    </main>

    <footer className="footer"><div className="footer-main"><button className="brand footer-brand" onClick={goHome}><span className="brand-mark"><FileText size={20}/></span><span>Convert<span className="brand-accent">Pro</span></span></button><p>Simple tools for everyday file tasks.</p><span className="footer-copy">© {new Date().getFullYear()} ConvertPro. Built for easier file workflows.</span></div><div className="footer-links"><a href="#tools" onClick={()=>setActive("home")}>Tools</a><a href="#how-it-works" onClick={()=>setActive("home")}>How it works</a><a href="mailto:hello@convertpro.example">Contact</a></div></footer>

    {notice&&<div className={`toast ${notice.type}`} role="status">{notice.type==="success"?<CheckCircle2 size={19}/>:<AlertCircle size={19}/>}<span>{notice.message}</span><button onClick={()=>setNotice(null)}><X size={16}/></button></div>}
  </div>;
}

export default App;