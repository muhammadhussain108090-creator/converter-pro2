export default async () => ({
  statusCode: 200,
  headers: { "content-type": "application/json", "cache-control": "no-store" },
  body: JSON.stringify({
    ok: true,
    service: "ConvertPro",
    message: "ConvertPro Netlify backend is online.",
    processing: "File transformations in version 1 run locally in the user's browser."
  })
});